<?php
define("DB_HOST","localhost");
define("DB_USER","id9969039_root");
define("DB_PASSWORD","kasdani12345");
define("DB_NAME","id9969039_kasdaani");
