<?php
include_once(__DIR__ . "/lib/format_data.php");
include_once(__DIR__."/lib/MKpilihan.php");

$MKpilihan = new MKpilihan();
$fmt = new FormatData();



if ($_GET['view'] == 'xml') {
	    echo $fmt->build_xml($MKpilihan->GetAll(), "mobil");
} else {
	echo '<h2 align=center>'."Data Mobil".'</h2>';
    echo $fmt->build_table($MKpilihan->getAll());
}
